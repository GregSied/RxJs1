import { Observable } from "rxjs-es";

let numbers = [1, 5, 10];
